# frozen_string_literal: true

class ReactController < ApplicationController
  def index
  end
end
