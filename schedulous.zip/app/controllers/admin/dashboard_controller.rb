# frozen_string_literal: true

class Admin::DashboardController < AdminController
  def index
  end
end
