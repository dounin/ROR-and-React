import React from "react";
import SettingsLayout from "~/layouts/SettingsLayout";

export default function Business() {
  return (
    <SettingsLayout title="Business Settings">Business Settings</SettingsLayout>
  );
}
