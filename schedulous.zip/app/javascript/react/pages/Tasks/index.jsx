import React from "react";
import Admin from "~/layouts/Admin";

export default function Tasks() {
  return <Admin title="Tasks"></Admin>;
}
