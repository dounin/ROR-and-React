import React from "react";
import Admin from "~/layouts/Admin";

export default function Calendar() {
  return <Admin title="Calendar"></Admin>;
}
