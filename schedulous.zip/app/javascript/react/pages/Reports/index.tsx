import React from "react";
import Admin from "~/layouts/Admin";

export default function Reports() {
  return <Admin title="Reports"></Admin>;
}
