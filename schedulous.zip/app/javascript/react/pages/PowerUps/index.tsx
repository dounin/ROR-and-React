import React from "react";
import Admin from "~/layouts/Admin";

export default function PowerUps() {
  return <Admin title="Power Ups"></Admin>;
}
