import React from "react";
import Admin from "~/layouts/Admin";

export default function Inbox() {
  return <Admin title="Inbox"></Admin>;
}
