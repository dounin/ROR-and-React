export type ISize = "none" | "small" | "medium" | "large";
