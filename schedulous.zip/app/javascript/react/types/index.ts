import { IColors } from "./colors";
import { ISize } from "./sizes";

export { IColors, ISize };
