export interface Person {
  id: number;
  email: string;
  phone?: string;
  first_name: string;
  last_name: string;
  name_familiar: string;
  has_user: string;
}
