export interface User {
  name: string | null;
  name_familiar: string | null;
  account_id: number | null;
  email: string | null;
  id: number | null;
  person_id: number | null;
  phone: string | null;
  created_at: string | null;
  updated_at: string | null;
}
