export interface TeamMember {
  id: number | null;
  name: string | null;
  role: string | null;
}
