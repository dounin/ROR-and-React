import React from "react";

export default function Authentication({ children }) {
  return <div>{children}</div>;
}
